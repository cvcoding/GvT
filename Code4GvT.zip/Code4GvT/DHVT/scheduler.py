import torch
import torch.nn as nn


class TrainScheduler(object):

    def __init__(self, model, blocks, keep_rates, optimizer, enter_epochs):
        pass